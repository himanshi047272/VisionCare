"""VisionCare API. Research prototype: not a medical device."""
import base64, io, os, platform, threading, time, json, sqlite3, csv, datetime
from pathlib import Path
import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile, Query
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
CKPT = Path(os.getenv("MODEL_PATH", ROOT / "models" / "checkpoint.pt"))
MAX_BYTES = int(os.getenv("MAX_UPLOAD_MB", "10")) * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 50_000_000
app = FastAPI(title="VisionCare Analytics", version="1.0.0")
_state = {"model": None, "meta": None, "err": None}
_lock = threading.Lock()
LATENCIES: list[float] = []

def _sig(b: bytes):
    if b[:4] == b"\x89PNG": return "png"
    if b[:3] == b"\xff\xd8\xff": return "jpeg"
    return None

def load_model():
    """Lazy, cached load. Never substitutes random weights."""
    with _lock:
        if _state["model"] is not None: return _state["model"]
        if not CKPT.exists():
            _state["err"] = "No checkpoint found. Run scripts/train.py first."; return None
        try:
            import torch, torchvision
            ck = torch.load(CKPT, map_location="cpu", weights_only=False)
            m = getattr(torchvision.models, ck["arch"])(weights=None)
            m.fc = torch.nn.Linear(m.fc.in_features, len(ck["classes"]))
            m.load_state_dict(ck["state_dict"]); m.eval()
            _state.update(model=m, meta={k: ck[k] for k in ("arch","classes","img_size","mean","std")}|{"trained_at": ck.get("trained_at"), "dataset": ck.get("dataset")}, err=None)
        except Exception as e:  # report, don't hide
            _state["err"] = f"Checkpoint failed to load: {type(e).__name__}"
        return _state["model"]

def preprocess(img: Image.Image, meta):
    import torch
    s = meta["img_size"]
    a = np.asarray(img.convert("RGB").resize((s, s), Image.BILINEAR), dtype=np.float32) / 255.0
    a = (a - np.array(meta["mean"], dtype=np.float32)) / np.array(meta["std"], dtype=np.float32)
    return torch.from_numpy(a.transpose(2, 0, 1)).unsqueeze(0), np.asarray(img.convert("RGB").resize((s, s)))

def gradcam(model, x, cls):
    import torch, torch.nn.functional as F
    store = {}
    def fh(_m, _i, out):
        store["a"] = out; out.register_hook(lambda g: store.__setitem__("g", g))
    h = model.layer4.register_forward_hook(fh)
    try:
        with torch.enable_grad():
            model.zero_grad(); out = model(x); out[0, cls].backward()
    finally:
        h.remove()
    w = store["g"].mean((2, 3), keepdim=True)
    cam = F.relu((w * store["a"]).sum(1, keepdim=True))
    cam = F.interpolate(cam, size=x.shape[2:], mode="bilinear", align_corners=False)[0, 0].detach().numpy()
    return (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)

def overlay_png(rgb, cam):
    import cv2
    heat = cv2.cvtColor(cv2.applyColorMap((cam * 255).astype("uint8"), cv2.COLORMAP_JET), cv2.COLOR_BGR2RGB)
    mix = (0.55 * rgb + 0.45 * heat).astype("uint8")
    buf = io.BytesIO(); Image.fromarray(mix).save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

@app.get("/api/health")
def health():
    info = {"status": "ok", "python": platform.python_version(), "model_file": CKPT.exists(), "max_upload_mb": MAX_BYTES // 2**20, "formats": ["png", "jpeg"], "retention_days": RETENTION, "store_thumbs": THUMBS}
    try:
        import torch; info |= {"torch": torch.__version__, "cuda": torch.cuda.is_available()}
    except ImportError:
        info["torch"] = None
    return info

@app.get("/api/model")
def model_info():
    load_model()
    if _state["meta"]: return {"available": True, **_state["meta"], "avg_latency_ms": round(sum(LATENCIES)/len(LATENCIES), 1) if LATENCIES else None}
    return {"available": False, "reason": _state["err"] or "Model not loaded"}

DB_PATH = Path(os.getenv("DB_PATH", ROOT / "artifacts" / "visioncare.db"))
RETENTION = int(os.getenv("RETENTION_DAYS", "30"))   # 0 = keep forever
THUMBS = os.getenv("STORE_THUMBS", "1") == "1"        # small previews kept with each record

def _db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH); c.row_factory = sqlite3.Row; return c

def _now(): return datetime.datetime.now(datetime.timezone.utc)

def init_db():
    with _db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS predictions(id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, label TEXT, confidence REAL, probs TEXT, classes TEXT, latency REAL, model TEXT, trained_at TEXT, thumb TEXT, cam TEXT)")
        if RETENTION > 0:
            c.execute("DELETE FROM predictions WHERE created < ?", ((_now() - datetime.timedelta(days=RETENTION)).isoformat(),))
init_db()

def _jpeg(img, size=256):
    im = img.convert("RGB"); im.thumbnail((size, size)); buf = io.BytesIO(); im.save(buf, "JPEG", quality=80)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

def overlay_img(rgb, cam):
    import cv2
    heat = cv2.cvtColor(cv2.applyColorMap((cam * 255).astype("uint8"), cv2.COLORMAP_JET), cv2.COLOR_BGR2RGB)
    return Image.fromarray((0.55 * rgb + 0.45 * heat).astype("uint8"))

@app.post("/api/predict")
async def predict(file: UploadFile = File(...), gradcam_map: bool = True, save: bool = True):
    data = await file.read(MAX_BYTES + 1)
    if not data: raise HTTPException(400, "Empty file")
    if len(data) > MAX_BYTES: raise HTTPException(413, "File too large")
    if not _sig(data): raise HTTPException(415, "Only PNG and JPEG are accepted")
    try:
        img = Image.open(io.BytesIO(data)); img.load()
    except Exception:
        raise HTTPException(422, "Corrupt or unreadable image")
    model = load_model()
    if model is None: raise HTTPException(503, _state["err"] or "Model unavailable")
    meta = _state["meta"]; t0 = time.perf_counter()
    x, rgb = preprocess(img, meta)
    import torch
    with torch.no_grad(): probs = torch.softmax(model(x), 1)[0].tolist()
    ms = (time.perf_counter() - t0) * 1000; LATENCIES.append(ms); del LATENCIES[:-200]
    top = int(np.argmax(probs))
    res = {"classes": meta["classes"], "probabilities": probs, "top_class": meta["classes"][top], "confidence": probs[top], "latency_ms": round(ms, 1),
           "model": meta["arch"], "trained_at": meta["trained_at"], "preprocessing": {"size": meta["img_size"], "mean": meta["mean"], "std": meta["std"]},
           "notice": "Experimental output. Not for diagnosis or treatment."}
    cam_img = None
    if gradcam_map:
        try:
            with _lock: cam_img = overlay_img(rgb, gradcam(model, x, top))
            buf = io.BytesIO(); cam_img.save(buf, "PNG"); res["gradcam"] = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
        except Exception as e: res["gradcam_error"] = f"Grad-CAM failed: {type(e).__name__}"
    if save:
        with _db() as c:
            cur = c.execute("INSERT INTO predictions(created,label,confidence,probs,classes,latency,model,trained_at,thumb,cam) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (_now().isoformat(), res["top_class"], probs[top], json.dumps(probs), json.dumps(meta["classes"]), ms, meta["arch"], meta["trained_at"],
                 _jpeg(img) if THUMBS else None, _jpeg(cam_img) if (THUMBS and cam_img is not None) else None))
            res["id"] = cur.lastrowid
    return res

@app.get("/api/predictions")
def list_predictions(limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0)):
    with _db() as c:
        rows = c.execute("SELECT id,created,label,confidence,latency,model,thumb FROM predictions ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset)).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/predictions/export.csv")
def export_predictions():
    with _db() as c: rows = c.execute("SELECT id,created,label,confidence,latency,model,probs FROM predictions ORDER BY id").fetchall()
    out = io.StringIO(); w = csv.writer(out); w.writerow(["id", "created_utc", "label", "confidence", "latency_ms", "model", "probabilities"])
    for r in rows: w.writerow(list(r))
    return Response(out.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=predictions.csv"})

@app.get("/api/predictions/{pid}")
def get_prediction(pid: int):
    with _db() as c: r = c.execute("SELECT * FROM predictions WHERE id=?", (pid,)).fetchone()
    if not r: raise HTTPException(404, "Not found")
    d = dict(r); d["probs"] = json.loads(d["probs"]); d["classes"] = json.loads(d["classes"]); return d

@app.delete("/api/predictions/{pid}")
def delete_prediction(pid: int):
    with _db() as c: c.execute("DELETE FROM predictions WHERE id=?", (pid,))
    return {"deleted": pid}

@app.delete("/api/predictions")
def delete_all():
    with _db() as c: c.execute("DELETE FROM predictions")
    return {"deleted": "all"}

@app.get("/api/stats")
def stats():
    wk = (_now() - datetime.timedelta(days=7)).isoformat()
    with _db() as c:
        total = c.execute("SELECT COUNT(*) FROM predictions").fetchone()[0]
        week = c.execute("SELECT COUNT(*) FROM predictions WHERE created >= ?", (wk,)).fetchone()[0]
        per = {r["label"]: r["n"] for r in c.execute("SELECT label, COUNT(*) n FROM predictions GROUP BY label")}
        avg = c.execute("SELECT AVG(latency) FROM predictions").fetchone()[0]
    return {"total": total, "this_week": week, "per_label": per, "avg_latency_ms": round(avg, 1) if avg is not None else None}

@app.get("/api/eval")
def last_eval():
    p = ROOT / "artifacts" / "eval.json"
    if not p.exists(): return {"available": False}
    return {"available": True, **json.loads(p.read_text())}

app.mount("/", StaticFiles(directory=ROOT / "frontend", html=True), name="ui")
