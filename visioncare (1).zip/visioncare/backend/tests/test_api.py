import io, os, sys, pathlib, tempfile
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from PIL import Image
from app.main import app
c = TestClient(app)

def png(w=32, h=32):
    b = io.BytesIO(); Image.new("L", (w, h), 128).save(b, "PNG"); return b.getvalue()

def test_health(): assert c.get("/api/health").json()["status"] == "ok"
def test_model_unavailable_is_reported(): assert c.get("/api/model").json()["available"] in (True, False)
def test_rejects_bad_format(): assert c.post("/api/predict", files={"file": ("a.gif", b"GIF89a....", "image/gif")}).status_code == 415
def test_rejects_empty(): assert c.post("/api/predict", files={"file": ("a.png", b"", "image/png")}).status_code == 400
def test_rejects_corrupt(): assert c.post("/api/predict", files={"file": ("a.png", b"\x89PNG garbage", "image/png")}).status_code == 422
def test_no_fake_prediction_without_model():
    r = c.post("/api/predict", files={"file": ("a.png", png(), "image/png")})
    assert r.status_code in (200, 503)
    if r.status_code == 503: assert "probabilities" not in r.json()
def test_stats_start_empty():
    j = c.get("/api/stats").json(); assert j["total"] >= 0 and "per_label" in j
def test_history_crud():
    assert c.get("/api/predictions").status_code == 200
    assert c.get("/api/predictions/999999").status_code == 404
    assert c.delete("/api/predictions").status_code == 200
    assert c.get("/api/predictions/export.csv").status_code == 200
