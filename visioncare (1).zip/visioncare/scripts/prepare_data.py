"""Re-split a folder-per-class image dataset into train/val/test while keeping near-duplicate images together.

Usage: python scripts/prepare_data.py --src <extracted_folder> --out data [--max-per-class 1500]

Why: merged and augmented datasets often contain several copies of one image. If copies land in different
splits, the test score is inflated. Existing train/test/val folders are merged and ignored; classes come from folder names.
Limits: catches near-identical copies (resized, recompressed, flipped, small brightness changes). Heavy
rotation or zoom can slip through. There are no patient IDs, so this is NOT patient-level separation.
Original files are copied, never modified."""
import argparse, collections, csv, pathlib, random, shutil
import numpy as np
from PIL import Image

ap = argparse.ArgumentParser()
ap.add_argument("--src", required=True); ap.add_argument("--out", default="data"); ap.add_argument("--seed", type=int, default=42)
ap.add_argument("--max-per-class", type=int, default=0, help="cap images per class (0 = all); useful for CPU training")
ap.add_argument("--ratios", default="0.7,0.15,0.15"); ap.add_argument("--dist", type=int, default=3, help="max differing hash bits (<=3)")
a = ap.parse_args(); assert 0 <= a.dist <= 3; random.seed(a.seed)
SPLITS, EXT = {"train", "test", "val", "valid", "validation"}, {".png", ".jpg", ".jpeg"}
src, out = pathlib.Path(a.src), pathlib.Path(a.out)
if out.exists() and any(out.iterdir()): raise SystemExit(f"{out} is not empty; choose another --out")
files = [(p, p.parent.name.strip().lower().replace(" ", "_")) for p in sorted(src.rglob("*"))
         if p.suffix.lower() in EXT and p.parent != src and p.parent.name.lower() not in SPLITS]

def dhash(p):
    try: v = np.asarray(Image.open(p).convert("L").resize((9, 8), Image.BILINEAR), dtype=np.int16)
    except Exception: return None
    bits = lambda m: int("".join("1" if t else "0" for t in (m[:, 1:] > m[:, :-1]).flatten()), 2)
    return min(bits(v), bits(v[:, ::-1]))   # same value for an image and its mirror

hs = [dhash(p) for p, _ in files]; keep = [i for i, h in enumerate(hs) if h is not None]
parent = list(range(len(files)))
def find(x):
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
buckets = collections.defaultdict(list)          # 4 x 16-bit chunks: hashes within 3 bits share >= 1 whole chunk
for i in keep:
    for k in range(4): buckets[(k, (hs[i] >> (16 * k)) & 0xFFFF)].append(i)
for lst in buckets.values():
    for x in range(len(lst)):
        for y in range(x + 1, len(lst)):
            i, j = lst[x], lst[y]
            if find(i) != find(j) and bin(hs[i] ^ hs[j]).count("1") <= a.dist: parent[find(i)] = find(j)
groups = collections.defaultdict(list)
for i in keep: groups[find(i)].append(i)
merged = sum(1 for g in groups.values() if len(g) > 1)
cross = sum(1 for g in groups.values() if len({files[i][1] for i in g}) > 1)
r = [float(x) for x in a.ratios.split(",")]; assert abs(sum(r) - 1) < 1e-6
bycls = collections.defaultdict(list)
for g in groups.values(): bycls[files[g[0]][1]].append(g)
rows, counts = [], collections.Counter()
for c, gs in sorted(bycls.items()):
    random.shuffle(gs)
    if a.max_per_class:
        sel, n = [], 0
        for g in gs:
            if n >= a.max_per_class: break
            sel.append(g); n += len(g)
        gs = sel
    tot, n = sum(len(g) for g in gs), 0
    for g in gs:
        f = n / tot; sp = "train" if f < r[0] else ("val" if f < r[0] + r[1] else "test")
        for i in g:
            d = out / sp / c; d.mkdir(parents=True, exist_ok=True); name = f"{i}_{files[i][0].name}"
            shutil.copy2(files[i][0], d / name); rows.append([sp, c, name, find(i)]); counts[(sp, c)] += 1
        n += len(g)
with open(out / "manifest.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["split", "class", "file", "dup_group"]); w.writerows(rows)
print(f"images found {len(files)}, unreadable {len(files) - len(keep)}, near-duplicate groups merged {merged}, groups spanning >1 class {cross}")
for sp in ("train", "val", "test"): print(sp, {c: counts[(sp, c)] for c in sorted(bycls)})
if cross: print("WARNING: some near-identical images carry different class labels. Inspect them before trusting results.")
