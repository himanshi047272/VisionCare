"""Train ResNet18 on a folder dataset: data/{train,val,test}/<class>/*.png|jpg
Usage: python scripts/train.py --data data --epochs 10 [--pretrained]
--pretrained downloads ImageNet weights (needs internet once)."""
import argparse, json, time, datetime, pathlib, torch, torchvision as tv, numpy as np
from torch import nn
from sklearn.metrics import classification_report, confusion_matrix
ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data"); ap.add_argument("--epochs", type=int, default=10); ap.add_argument("--bs", type=int, default=16)
ap.add_argument("--lr", type=float, default=1e-3); ap.add_argument("--size", type=int, default=224); ap.add_argument("--seed", type=int, default=42)
ap.add_argument("--patience", type=int, default=3); ap.add_argument("--pretrained", action="store_true"); ap.add_argument("--out", default="models/checkpoint.pt")
a = ap.parse_args(); torch.manual_seed(a.seed); np.random.seed(a.seed)
mean, std = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]
ev = tv.transforms.Compose([tv.transforms.Grayscale(3), tv.transforms.Resize((a.size, a.size)), tv.transforms.ToTensor(), tv.transforms.Normalize(mean, std)])
tr = tv.transforms.Compose([tv.transforms.Grayscale(3), tv.transforms.Resize((a.size, a.size)), tv.transforms.RandomRotation(7), tv.transforms.ToTensor(), tv.transforms.Normalize(mean, std)])
D = pathlib.Path(a.data)
ds = {k: tv.datasets.ImageFolder(D / k, tr if k == "train" else ev) for k in ("train", "val", "test")}
classes = ds["train"].classes
assert all(ds[k].classes == classes for k in ds), "class folders differ between splits"
ld = {k: torch.utils.data.DataLoader(v, batch_size=a.bs, shuffle=(k == "train")) for k, v in ds.items()}
m = tv.models.resnet18(weights="IMAGENET1K_V1" if a.pretrained else None); m.fc = nn.Linear(m.fc.in_features, len(classes))
opt = torch.optim.Adam(m.parameters(), lr=a.lr); cnt = np.bincount(ds['train'].targets, minlength=len(classes)); lossf = nn.CrossEntropyLoss(weight=torch.tensor(cnt.sum() / (len(classes) * np.maximum(cnt, 1)), dtype=torch.float32))  # offsets class imbalance
def run(split, train=False):
    m.train(train); tot = n = 0; ys, ps = [], []
    for x, y in ld[split]:
        with torch.set_grad_enabled(train):
            o = m(x); l = lossf(o, y)
            if not torch.isfinite(l): raise RuntimeError("Non-finite loss; training aborted")
            if train: opt.zero_grad(); l.backward(); opt.step()
        tot += l.item() * len(y); n += len(y); ys += y.tolist(); ps += o.argmax(1).tolist()
    return tot / n, ys, ps
best, bad, state, hist = 9e9, 0, None, []
for e in range(a.epochs):
    tl, *_ = run("train", True); vl, *_ = run("val"); hist.append({"epoch": e + 1, "train_loss": tl, "val_loss": vl}); print(hist[-1])
    if vl < best: best, bad, state = vl, 0, {k: v.clone() for k, v in m.state_dict().items()}
    else:
        bad += 1
        if bad >= a.patience: print("early stop"); break
m.load_state_dict(state)
_, y, p = run("test")  # test split used once, after model selection on val
rep = classification_report(y, p, target_names=classes, output_dict=True, zero_division=0)
pathlib.Path("artifacts").mkdir(exist_ok=True)
json.dump({"classes": classes, "report": rep, "confusion": confusion_matrix(y, p).tolist(), "n_test": len(y), "history": hist, "seed": a.seed, "args": vars(a), "torch": torch.__version__}, open("artifacts/eval.json", "w"), indent=1)
torch.save({"arch": "resnet18", "classes": classes, "state_dict": m.state_dict(), "img_size": a.size, "mean": mean, "std": std,
            "trained_at": datetime.datetime.now().isoformat(timespec="seconds"), "dataset": str(D)}, a.out)
print("saved", a.out, "test accuracy", rep["accuracy"])
