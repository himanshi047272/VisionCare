# VisionCare Analytics
Research notebook for chest X-ray image classification: dataset checks, metrics, ResNet18 inference and Grad-CAM. **Not a medical device. No diagnosis or treatment use.**

## Run locally
```
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install --extra-index-url https://download.pytorch.org/whl/cpu -r backend/requirements.txt
uvicorn app.main:app --app-dir backend --reload        # open http://localhost:8000
```
Without a checkpoint the app still runs; the UI says the model is unavailable and refuses to predict.

## Get a real model
1. Download a chest X-ray dataset whose licence allows your use (e.g. a Kaggle/NIH/CheXpert-style set; check its terms yourself).
2. Arrange it as `data/{train,val,test}/<class_name>/*.png` (split by patient if you have IDs; the script cannot check this).
3. `python scripts/train.py --data data --epochs 10 --pretrained` (`--pretrained` needs internet once; omit to train from scratch). CPU is fine for small sets.
4. Output: `models/checkpoint.pt` and `artifacts/eval.json` (test metrics, produced once after validation-based selection). Restart the server.

## Tests
`cd backend && pytest -q`

## Docker / deploy
`docker compose up --build` then open http://localhost:8000. Put `checkpoint.pt` in `./models`. For hosting, push the image to Render, Fly.io, Railway or any VM; set `PORT` if required and mount or bake in the checkpoint. Use HTTPS and add authentication before exposing it publicly.

## Env vars
`MODEL_PATH` (default `models/checkpoint.pt`), `MAX_UPLOAD_MB` (default 10).

## Privacy
Uploads are processed in memory and not stored. Dataset import in the Library tab runs entirely in the browser.

## Limits
Labels may be noisy; results may not transfer between hospitals or scanners; Grad-CAM is exploratory only; split leakage is your responsibility without patient IDs.

## Features
Dashboard stats from saved predictions, drag-and-drop upload (several images at once) with class probabilities, latency and Grad-CAM, history with view, delete and CSV export, dataset checker, model test results from `artifacts/eval.json`, system settings. Saved previews are kept for `RETENTION_DAYS` (default 30; `STORE_THUMBS=0` keeps none).

## Important
No trained weights ship with this project. Until you run `scripts/train.py` on a dataset you are licensed to use, the app reports "No model loaded" and makes no predictions.

## Training on the Kaggle "Lungs Disease Dataset (4 types)"
1. Download and unzip it. Check the licence and folder layout on its Kaggle page.
2. Re-split without leaking near-duplicates (the dataset is merged from several sources and augmented):
   `python scripts/prepare_data.py --src <unzipped_folder> --out data --max-per-class 1500`
   (`--max-per-class` keeps CPU training manageable; omit it to use everything.)
3. `python scripts/train.py --data data --epochs 8 --pretrained --lr 1e-4 --size 160`
4. Restart the server. Test results appear under Insights.
Caveats: images come from different sources, so a model can learn the source (scanner, crop, contrast) instead of the disease. A high test score here does not show it works on new hospitals. No patient IDs exist, so splits are not patient-level.
